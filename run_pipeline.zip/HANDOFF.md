# HANDOFF: Universal Benchmark Refactor (Stages 11–18)

## PROJECT STATE
Complete. The benchmarking pipeline from Stage 11 onward has been universalized. The canonical interface contract is a cleaned plain-text corpus (`*_corpus.txt`), separated by double newlines (`\n\n`). Stages 11–18 have zero dependencies on `clean_documents.jsonl`, MARSIS schemas, `OccID`, `VesselID`, or hardcoded domain fields. All tests and static dependency audits pass with zero violations.

## LAST COMPLETED STAGE
Universal Benchmark Core (Stages 11–18 Refactor):
- Stage 11: Multi-format representations generated purely from text via deterministic rule extraction and SHA-256 template hashing.
- Stage 12: Text-derived semantic importance scoring and knowledge classification.
- Stage 13: Domain-agnostic tokenizer analysis consuming plain-text corpus and vocabulary.
- Stage 14: MLM evaluation configured for generic domain categories, matching by `doc_id`, 175-run matrix grid.
- Stage 15: Cross-model benchmarking with configurable Domain Understanding Index (DUI/MUI) and dynamic category recall.
- Stage 16: Statistical significance testing with strictly aligned pairing on `(representation, subset)` and empirical feature ablation calculations.
- Stage 17: Parameterized decision engine reading thresholds from `config.json`.
- Stage 18: Quality linting executed directly on the plain-text corpus.

## CURRENT TASK
Refactor complete. Final validation and verification completed.

## FILES CHANGED
- `config/config.json`: Added `benchmark` and `decision` sections.
- `scripts/pipeline_utils.py`: Added `load_corpus_documents()` and `get_benchmark_config()`.
- `scripts/11_corpus_representations.py`: Refactored to read `.txt` corpus.
- `scripts/12_semantic_importance.py`: Text-derived semantic importance scoring.
- `scripts/13_tokenizer_analysis.py`: Refactored to consume `.txt` corpus directly.
- `scripts/14_mlm_evaluation.py`: Decoupled from MARSIS data; documented 175 runs.
- `scripts/15_cross_model_benchmarking.py`: Generic DUI calculation and dynamic recall.
- `scripts/16_statistical_analysis.py`: Fixed pairing alignment and implemented real ablation.
- `scripts/17_decision_engine.py`: Dynamic domain naming and configurable thresholds.
- `scripts/18_lint_corpus.py`: Plain-text corpus quality linter.
- `outputs/*`: Updated output JSON reports, statistical tests, and ablation study.

## FILES CREATED
- `HANDOFF.md`: Repository root handoff file.
- `tests/domain_test_corpus.txt`: Synthetic non-maritime corpus.
- `tests/test_universal_benchmark.py`: Comprehensive test suite (12 tests) including static AST audit.
- `documentation/15_universal_benchmark_refactor.md`: In-depth documentation.

## TESTS PASSED
- `tests/test_universal_benchmark.py`: 12/12 PASSED (TXT loading, boundary detection, deduplication, representations, text scoring, real ablation, paired alignment, decision engine, synthetic non-maritime corpus, and static dependency audit).
- `tests/test_quality_optimizations.py`: 7/7 PASSED.
- `tests/verify_pipeline.py`: ALL 25 REQUIRED OUTPUTS VERIFIED.
- Static dependency audit: ZERO forbidden tokens across `scripts/11*` through `scripts/18*`.

## KNOWN FAILURES
None.

## NEXT ACTIONS
1. To run on a new domain:
   - Provide `your_domain_corpus.txt` in `outputs/`.
   - Update `config/config.json` (`benchmark.domain_name`, `benchmark.corpus_file`, `benchmark.categories`).
   - Run `python run_pipeline.py --stage 11` (through 18).

## IMPORTANT DESIGN DECISIONS
- The canonical interface is plain-text `*_corpus.txt` with `\n\n` document boundary delimiters.
- Document identifier is `doc_id` with `occurrence_id` retained as a backwards-compatible alias.
- Stage 16 pairs observations strictly on `(representation, subset)` keys ($N=25$ paired cells per model comparison).
- Feature ablation in Stage 16 is calculated empirically over document feature vectors.
- Decision engine thresholds in `config.json` support both decimal (0.85) and percentage (85.0) representations.

## DO NOT CHANGE
- `dapt/` directory (untouched).
- `maritimebert_validation.ipynb` (untouched).
- Stages 01–10 (domain-specific corpus construction).
- `clean_documents.jsonl` (preserved for upstream provenance, but ignored by Stages 11–18).
